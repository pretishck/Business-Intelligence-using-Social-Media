from FilterTweets import *
import pickle
import csv

f = open('nbc.pickle')
NBClassifier = pickle.load(f)

inp_tweet = csv.reader(open('data/test_data.csv','rb'))
out_tweet = csv.writer(open('data/out_put_data.csv','wb'))
output_data = []
for row in inp_tweet:
	t_id = row[0]
    created_at = row[1]
    test_tweet = row[2]
    name = row[4]
    screen_name = row[3]
    followers_count = row[5]
    friends_count = row[6]
    statuses_count = row[7]
    retweet_count = row[8]
    location = row[9]
    mention1 = row[10]
    mention2 = row[11]
    hashtag1 = row[12]
    hashtag2 = row[13]
    hashtag3 = row[14]
    hashtag4 = row[15]
    url1 = row[16]
    url2 = row[17]
    lat = row[18]
    lon = row[19]
    place_name = row[20]
    place_type = row[21]
    timestamp = row[22]
	polarity = NBClassifier.classify(extract_features(getFeatureVector(processTweet(testTweet))))
	output_data.appen((t_id,created_at,test_tweet,polarity,name,screen_name,followers_count,friends_count,statuses_count,retweet_count,location,mention1,mention2,
		hashtag1,hashtag2,hashtag3,hashtag4,url1,url2,lat,lon,place_name,place_type,timestamp))
	#print NBClassifier.show_most_informative_features(60)
out_tweet.writerows(output_data)
out_tweet.close()
f.close()
