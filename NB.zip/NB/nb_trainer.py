# import FilterTweets
from FilterTweets import *
import pickle
f = open('nbc.pickle', 'wb')
# Train the classifier
NBClassifier = nltk.NaiveBayesClassifier.train(training_set)
pickle.dump(NBClassifier, f)
f.close()
f1 = open('nbc.pickle')
NBClassifier = pickle.load(f1)
# Test the classifier
testTweet = 'I am so badly hurt'
#processedTestTweet = processTweet(testTweet)
print ("Output:")
print NBClassifier.classify(extract_features(getFeatureVector(processTweet(testTweet))))
print NBClassifier.show_most_informative_features(60)
f1.close()