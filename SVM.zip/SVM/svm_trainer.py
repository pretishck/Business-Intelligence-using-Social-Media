import svm
from svmutil import *
from processTweet import *
from feature_vector import *
from word_list import *

featureList = getFeatureList('feature_1.txt')
#get the input
import csv
inpTweets_1 = csv.reader(open('data/Book1.csv','rb'))
tweets = []
for row in inpTweets_1:
    sentiment = row[1]
    #if sentiment == 0 or sentiment == 2 or sentiment == 4 or sentiment == 6:
      
    tweet = row[0]
    #processedTweet = word_tokenizer(re.sub('((www\.[^\s]+)|(https?://[^\s]+))','URL',tweet))
    processedTweet = processTweet(tweet)
        #for p in processedTweet:
         #   print p
    featureVector = getFeatureVector(processedTweet)
    #featureVector=getFeatureVector(processedTweet)
    #featureList.extend(featureVector) 
    tweets.append((featureVector, sentiment))
    #else:
     #   continue

#Train the classifier

result = getSVMFeatureVectorAndLabels(tweets, featureList)
problem = svm_problem(result['labels'], result['feature_vector'])
#'-q' option suppress console output
param = svm_parameter('-q')
param.kernel_type = LINEAR
classifier = svm_train(problem, param)
svm_save_model("svm_final_classifer", classifier)
test_tweet = "apple is not performing well at these days"
data = processTweet(test_tweet)
test_feature_vector = getSVMFeatureVector(getFeatureVector(data), featureList)
    #p_labels contains the final labeling result
p_labels, p_accs, p_vals = svm_predict([0] * len(test_feature_vector),test_feature_vector, classifier)
print p_labels
