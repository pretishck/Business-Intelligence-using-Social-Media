import svm
from svmutil import *
from processTweet import *
from feature_vector import *
from word_list import *
import csv
from hashtags import *

featureList = getFeatureList('feature_1.txt')

classifier = svm_load_model("svm_final_classifer")

f1 = open('data/output_final_check_with_sentiment.csv', 'w')
output = csv.writer(f1, delimiter=',')
f2 = open('data/bookdata.csv', 'rb')
input_test_tweet = csv.reader(f2)
output_data = []
output_data_a = []
output_data_t = []
output_data_s = []
output_data_m = []
output_data_sa = []
output_data_g = []
output_data_i = []
output_data_lg = []
output_data_l = []
output_data_n = []
#Test the classifier using the test data csv file
fa = open('data/apple.csv','w+')
out_fa = csv.writer(fa, delimiter=',')
ft = open('data/twitter.csv', 'w+')
out_ft = csv.writer(ft, delimiter=',')
fs= open('data/sony.csv', 'w+')
out_fs = csv.writer(fs, delimiter=',')
fm = open('data/microsoft.csv', 'w+')
out_fm= csv.writer(fm, delimiter=',')
fsa = open('data/samsung.csv', 'w+')
out_fsa = csv.writer(fsa, delimiter=',')
fg = open('data/google.csv', 'w+')
out_fg = csv.writer(fg, delimiter=',')
fi = open('data/ibm.csv', 'w+')
out_fi = csv.writer(fi, delimiter=',')
fl = open('data/lenovo.csv', 'w+')
out_fl = csv.writer(fl, delimiter=',')
flg = open('data/lg.csv', 'w+')
out_flg = csv.writer(flg, delimiter=',')
fn = open('data/nokia.csv', 'w+')
out_fn = csv.writer(fn, delimiter=',')
for row in input_test_tweet:
    t_id = row[0]
    created_at = row[1]
    test_tweet = row[2]
    name = row[4]
    screen_name = row[3]
    followers_count = row[5]
    friends_count = row[6]
    statuses_count = row[7]
    retweet_count = row[8]
    location = row[9]
    mention1 = row[10]
    mention2 = row[11]
    hashtag1 = row[12]
    hashtag2 = row[13]
    hashtag3 = row[14]
    hashtag4 = row[15]
    url1 = row[16]
    url2 = row[17]
    lat = row[18]
    lon = row[19]
    place_name = row[20]
    place_type = row[21]
    timestamp = row[22]

    data = processTweet(test_tweet)
    test_feature_vector = getSVMFeatureVector(getFeatureVector(data), featureList)
    #p_labels contains the final labeling result
    p_labels, p_accs, p_vals = svm_predict([0] * len(test_feature_vector),test_feature_vector, classifier)
    print p_labels
    if re.search(twitter, data):
    	output_data_t.append((data,p_labels[0]))
    if re.search(apple, data):
    	output_data_a.append((data,p_labels[0]))
    if re.search(sony, data):
    	output_data_s.append((data,p_labels[0]))
    if re.search(google, data):
    	output_data_g.append((data,p_labels[0]))
    if re.search(microsoft, data):
    	output_data_m.append((data,p_labels[0]))
    if re.search(samsung, data):
    	output_data_sa.append((data,p_labels[0]))
    if re.search(ibm, data):
    	output_data_i.append((data,p_labels[0]))
    if re.search(lg, data):
    	output_data_lg.append((data,p_labels[0]))
    if re.search(nokia, data):
    	output_data_n.append((data,p_labels[0]))
    if re.search(lenovo, data):
    	output_data_l.append((data,p_labels[0]))
    else:
    	output_data.append((data, p_labels[0]))

output.writerows(output_data)
out_fa.writerows(output_data_a)
out_ft.writerows(output_data_t)
out_fs.writerows(output_data_s)
out_fg.writerows(output_data_g)
out_fm.writerows(output_data_m)
out_fsa.writerows(output_data_sa)
out_fi.writerows(output_data_i)
out_flg.writerows(output_data_lg)
out_fl.writerows(output_data_l)
out_fn.writerows(output_data_n)

fa.close()
f1.close()
ft.close()
fs.close()
fsa.close()
fg.close()
fm.close()
fi.close()
flg.close()
fl.close()
fn.close()